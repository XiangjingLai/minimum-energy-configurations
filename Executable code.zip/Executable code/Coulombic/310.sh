#!/bin/sh
./HEA 310 10 3600
