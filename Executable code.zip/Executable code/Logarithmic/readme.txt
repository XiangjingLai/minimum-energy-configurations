1) Input parameters 
The program HEALOG contains following input parameters, where N is the number of points, 
NumberOfRuns is the number of times of running the algorithm,
and TimeLimit is the time limit (in seconds) for each run of algorithm:
————————————————————————————————————————
./HEALOG   N   NumberOfRuns  TimeLimit 
————————————————————————————————————————

2) Submission of jobs
The parameters of program can be located in a script file named 'N.sh', where N is the number of points. 
Under a linux operating system, the job 'N.sh' can be submitted as follows:
-----------------------------------------
chmod 777 HEALOG
chmod 777 N.sh 
sbatch N.sh
-----------------------------------------


3) Computational results: 
The computational results are summarized in a text file named "CompuptationalResesults.txt", 
and for each instance the following information is given:
——————————————————————————————————————————————————————————————————————————
N     f_{best}      f_{avg}      f_{worst}      Sigma    Time_avg
——————————————————————————————————————————————————————————————————————————
where N is the number of points, f_{best}, f_{avg} and f_{worst} represent respectively the best, average, and worst results over 'NumberOfRuns' runs. 
"Sigma" is the standard deviation of objective values obtained（f）,  and "Time_avg" represents the average computational time (in seconds) for each run of algorithm to reach its final objective value.   


