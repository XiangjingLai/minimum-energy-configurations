#!/bin/sh
./HEALOG 310 10 7200